import React, { useState } from 'react';
import { X, ArrowUpRight, Copy, Check, Users } from 'lucide-react';
import { TRADER_MIX_DATA } from '../data/traderData';

interface CommunityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CommunityModal: React.FC<CommunityModalProps> = ({ isOpen, onClose }) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (id: string, url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-lg rounded-2xl glass-panel border-2 border-[#ffc107]/40 bg-[#12100d] p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.85)] max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-[#1f1913] text-[#b4a796] hover:text-white transition-all cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-12 h-12 rounded-full bg-[#ffc107]/20 border border-[#ffc107]/40 text-[#ffc107] mx-auto flex items-center justify-center mb-3">
            <Users className="w-6 h-6" />
          </div>
          <h3 className="font-cinzel text-2xl font-bold text-white">
            Join The <span className="text-gold-gradient">Trader Mix Family</span>
          </h3>
          <p className="text-xs text-[#a39789] mt-1 font-jakarta">
            Connect across all 4 official channels for daily market analysis and updates.
          </p>
        </div>

        {/* 4 Platforms list */}
        <div className="space-y-3 mb-6">
          {TRADER_MIX_DATA.platforms.map((platform) => (
            <div
              key={platform.id}
              className="p-3.5 rounded-xl bg-[#171410] border border-[#ffc107]/20 flex items-center justify-between gap-3 hover:border-[#ffc107]/60 transition-all"
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-white shrink-0 font-bold"
                  style={{ backgroundColor: platform.color }}
                >
                  {platform.name.charAt(0)}
                </div>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-1.5 font-jakarta">
                    <span>{platform.name}</span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#ffc107]/20 text-[#ffc107] font-bold">
                      {platform.badge}
                    </span>
                  </div>
                  <div className="text-[11px] text-[#a99e90] font-mono-nums">
                    {platform.handle}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={platform.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-lg bg-[#272016] border border-[#ffc107]/40 text-xs font-bold text-[#FFDE59] hover:bg-[#34291c] transition-all flex items-center gap-1"
                >
                  <span>Open</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>

                <button
                  onClick={() => handleCopy(platform.id, platform.url)}
                  className="p-1.5 rounded-lg bg-[#1b1712] border border-[#ffc107]/20 text-[#8e8274] hover:text-white transition-all cursor-pointer"
                  title="Copy link"
                >
                  {copiedId === platform.id ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-lg bg-[#181410] border border-[#ffc107]/20 text-xs text-[#a99e90] hover:text-white transition-colors cursor-pointer"
        >
          Close Window
        </button>

      </div>
    </div>
  );
};
