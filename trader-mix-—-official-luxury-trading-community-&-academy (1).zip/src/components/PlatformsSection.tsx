import React, { useState } from 'react';
import { ArrowUpRight, Copy, Check, Share2, Sparkles } from 'lucide-react';
import { TRADER_MIX_DATA, PlatformLink } from '../data/traderData';

export const PlatformsSection: React.FC = () => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (id: string, url: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const renderIcon = (type: string) => {
    switch (type) {
      case 'telegram':
        return (
          <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
            <path d="M21.7 3.3 18.5 20c-.2 1.2-.9 1.5-1.8 1l-5-3.7-2.4 2.3c-.3.3-.5.5-1 .5l.4-5.1 9.3-8.4c.4-.4-.1-.6-.6-.2L6 13.7 1.1 12.2c-1.1-.3-1.1-1.1.2-1.6L20.4 3.2c.9-.3 1.7.2 1.3 1.1Z"/>
          </svg>
        );
      case 'facebook':
        return (
          <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
            <path d="M13.5 21v-8h2.7l.4-3.1h-3.1v-2c0-.9.3-1.5 1.6-1.5h1.7V3.6c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3v2.1H7.3V13h2.8v8h3.4Z"/>
          </svg>
        );
      case 'tiktok':
        return (
          <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
            <path d="M19.6 8.2a7.1 7.1 0 0 1-4.2-1.4v7.1a5.8 5.8 0 1 1-5-5.7v3.6a2.3 2.3 0 1 0 1.6 2.2V2.5h3.4c.2 2.1 1.9 3.8 4.2 4v1.7Z"/>
          </svg>
        );
      case 'youtube':
        return (
          <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
            <path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.6 12 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 0 0 .5 6.2 31 31 0 0 0 0 12a31 31 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1A31 31 0 0 0 24 12a31 31 0 0 0-.5-5.8ZM9.6 15.6V8.4l6.3 3.6-6.3 3.6Z"/>
          </svg>
        );
      default:
        return <Share2 className="w-6 h-6" />;
    }
  };

  return (
    <section id="platforms" className="relative py-20 lg:py-28 bg-[#0d0b09] border-t border-b border-[#d6b17a]/15 overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#d6b17a]/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1f1913] border border-[#d6b17a]/25 text-xs text-[#f0d29b] font-bold tracking-[0.2em] uppercase mb-3">
            <Share2 className="w-3.5 h-3.5 text-[#f0d29b]" />
            <span>Connect & Follow</span>
          </div>

          <h2 className="font-cinzel text-3xl sm:text-5xl font-bold text-[#f7f2ea] mb-4">
            Official <span className="text-gold-gradient">Community Platforms</span>
          </h2>

          <p className="font-jakarta text-[#b8ada0] text-sm sm:text-base leading-relaxed">
            Stay connected with Trader Mix across all official networks for daily setups, live videos, 
            market psychology, and announcements.
          </p>
        </div>

        {/* 4 Platforms Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {TRADER_MIX_DATA.platforms.map((platform) => (
            <div
              key={platform.id}
              className="glass-panel rounded-2xl p-6 flex flex-col justify-between border border-[#d6b17a]/20 hover:border-[#f0d29b]/60 transition-all duration-300 group hover:-translate-y-1.5 shadow-[0_10px_30px_rgba(0,0,0,0.4)]"
            >
              <div>
                {/* Header with icon and platform badge */}
                <div className="flex items-center justify-between mb-5">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center shadow-lg transition-transform group-hover:scale-110"
                    style={{
                      backgroundColor: `${platform.color}15`,
                      color: platform.color,
                      border: `1px solid ${platform.color}40`
                    }}
                  >
                    {renderIcon(platform.icon)}
                  </div>

                  <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-1 rounded-full bg-[#181410] border border-[#d6b17a]/20 text-[#d4c8b8]">
                    {platform.badge}
                  </span>
                </div>

                {/* Platform Name & Handle */}
                <h3 className="font-bold text-lg text-[#f7f2ea] mb-1 font-jakarta group-hover:text-[#f3dcaf] transition-colors">
                  {platform.name}
                </h3>
                <div className="text-xs font-mono-nums font-semibold text-[#d6b17a] mb-3">
                  {platform.handle}
                </div>

                {/* Description */}
                <p className="text-xs text-[#a4998b] leading-relaxed mb-6 font-jakarta">
                  {platform.description}
                </p>
              </div>

              {/* Bottom Actions: Visit Button + Copy Link */}
              <div className="pt-4 border-t border-[#d6b17a]/15 flex items-center gap-2">
                <a
                  href={platform.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-2.5 px-3 rounded-lg bg-gradient-to-r from-[#211a13] to-[#16120e] border border-[#d6b17a]/30 hover:border-[#f0d29b] text-[#f0d29b] text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-sm group-hover:bg-[#d6b17a]/10"
                >
                  <span>{platform.members}</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>

                <button
                  onClick={(e) => handleCopy(platform.id, platform.url, e)}
                  title="Copy link"
                  className="p-2.5 rounded-lg bg-[#15120e] border border-[#d6b17a]/20 text-[#a99e90] hover:text-[#f0d29b] hover:border-[#f0d29b]/40 transition-all cursor-pointer"
                  aria-label={`Copy link for ${platform.name}`}
                >
                  {copiedId === platform.id ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Telegram Direct Banner Callout */}
        <div className="mt-12 glass-panel rounded-2xl p-6 sm:p-8 border border-[#38bdf8]/30 bg-gradient-to-r from-[#111922] via-[#161d24] to-[#12161b] max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6 shadow-2xl">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-[#38bdf8]/15 border border-[#38bdf8]/40 flex items-center justify-center text-[#38bdf8] shrink-0">
              <svg className="w-7 h-7 fill-current" viewBox="0 0 24 24">
                <path d="M21.7 3.3 18.5 20c-.2 1.2-.9 1.5-1.8 1l-5-3.7-2.4 2.3c-.3.3-.5.5-1 .5l.4-5.1 9.3-8.4c.4-.4-.1-.6-.6-.2L6 13.7 1.1 12.2c-1.1-.3-1.1-1.1.2-1.6L20.4 3.2c.9-.3 1.7.2 1.3 1.1Z"/>
              </svg>
            </div>
            <div>
              <div className="text-xs uppercase font-bold text-[#38bdf8] tracking-wider mb-0.5">
                Primary Notification Channel
              </div>
              <h4 className="text-base sm:text-lg font-bold text-[#f7f2eb]">
                Never Miss A Live Price Action Breakdown
              </h4>
              <p className="text-xs text-[#9bb0c1] mt-0.5">
                Join our Telegram channel now for real-time market insights and session notices.
              </p>
            </div>
          </div>

          <a
            href={TRADER_MIX_DATA.platforms[0].url}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-[#38bdf8] text-[#0b1319] font-bold text-xs sm:text-sm hover:brightness-110 active:scale-95 transition-all shadow-lg flex items-center justify-center gap-2 whitespace-nowrap shrink-0"
          >
            <span>Open Telegram @TraderMix00</span>
            <ArrowUpRight className="w-4 h-4 text-[#0b1319]" />
          </a>
        </div>

      </div>
    </section>
  );
};
