import React, { useState } from 'react';
import { Check, Sparkles, BookOpen, Clock, ShieldCheck, Flame, ArrowRight, Zap, Target } from 'lucide-react';
import { TRADER_MIX_DATA } from '../data/traderData';

interface CourseSectionProps {
  onOpenEnrollModal: () => void;
}

export const CourseSection: React.FC<CourseSectionProps> = ({ onOpenEnrollModal }) => {
  const [activeTab, setActiveTab] = useState(0);
  const course = TRADER_MIX_DATA.course;

  return (
    <section id="course" className="relative py-20 lg:py-28 bg-[#0b0a09] overflow-hidden">
      {/* Background ambient light */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-full max-w-4xl h-96 bg-[#d6b17a]/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#241d15] border border-[#f0d29b]/40 text-xs text-[#f0d29b] font-bold tracking-[0.2em] uppercase mb-3 shadow-[0_0_15px_rgba(214,177,122,0.2)]">
            <Sparkles className="w-3.5 h-3.5 text-[#f0d29b]" />
            <span>Masterclass & Mentorship • $150</span>
          </div>

          <h2 className="font-cinzel text-3xl sm:text-5xl font-extrabold text-[#f7f2ea] mb-4">
            The Complete Trading <span className="text-gold-gradient">Mastery Program</span>
          </h2>

          <p className="font-jakarta text-[#b8ada0] text-sm sm:text-base leading-relaxed">
            Everything you need to trade institutional price action, pass prop firm evaluations, and gain psychological consistency for a one-time enrollment of <span className="text-[#f0d29b] font-bold font-mono-nums">$150</span>.
          </p>
        </div>

        {/* Pricing & Value Presentation Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch mb-16">
          
          {/* Main $150 Enrollment Card */}
          <div className="lg:col-span-5 flex flex-col justify-between glass-panel rounded-2xl p-6 sm:p-8 border-2 border-[#d6b17a]/40 shadow-[0_20px_50px_rgba(0,0,0,0.7)] relative overflow-hidden">
            {/* Top gold ribbon */}
            <div className="absolute top-0 right-0 bg-gradient-to-l from-[#f0d29b] to-[#ca9b58] text-[#14100b] text-[10px] sm:text-xs font-black uppercase tracking-wider px-4 py-1.5 rounded-bl-xl shadow-md font-jakarta">
              Limited Enrolment
            </div>

            <div>
              <div className="text-xs uppercase tracking-[0.2em] text-[#d6b17a] font-bold mb-2">
                Lifetime VIP Membership
              </div>
              <h3 className="font-cinzel text-2xl sm:text-3xl font-bold text-[#eee7dc] mb-4">
                Elite Mentorship
              </h3>

              {/* Price Tag Display */}
              <div className="flex items-baseline gap-3 mb-2">
                <span className="font-cinzel text-5xl sm:text-6xl font-black text-gold-gradient font-mono-nums">
                  ${course.price}
                </span>
                <span className="text-lg text-[#7c7164] line-through font-mono-nums">
                  ${course.originalPrice}
                </span>
                <span className="text-xs font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded">
                  70% OFF
                </span>
              </div>
              
              <div className="text-xs text-[#a39789] mb-6 flex items-center gap-1.5 font-jakarta">
                <Check className="w-3.5 h-3.5 text-[#d6b17a]" />
                <span>One-time payment • No monthly subscription fees</span>
              </div>

              {/* Features List */}
              <div className="space-y-3 pt-2 border-t border-[#d6b17a]/15 mb-8">
                {course.features.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-[#ddd2c5]">
                    <span className="w-4 h-4 rounded-full bg-[#d6b17a]/20 border border-[#d6b17a]/40 flex items-center justify-center shrink-0 mt-0.5">
                      <Check className="w-2.5 h-2.5 text-[#f0d29b]" />
                    </span>
                    <span className="leading-snug">{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3 pt-4 border-t border-[#d6b17a]/15">
              <button
                onClick={onOpenEnrollModal}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-[#f0d29b] via-[#e2b774] to-[#c79b61] text-[#14100b] font-black text-sm sm:text-base tracking-wide shadow-[0_8px_30px_rgba(214,177,122,0.4)] hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Enroll in Course for $150</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="text-center">
                <span className="text-[11px] text-[#8e8273]">
                  Direct mentorship by Shaheen • Instant Telegram VIP invite
                </span>
              </div>
            </div>

          </div>

          {/* Curriculum & Practical Syllabus */}
          <div className="lg:col-span-7 flex flex-col justify-between glass-panel rounded-2xl p-6 sm:p-8 border border-[#d6b17a]/20">
            <div>
              <div className="flex items-center justify-between mb-6 pb-4 border-b border-[#d6b17a]/15">
                <div>
                  <span className="text-xs uppercase tracking-[0.2em] text-[#d6b17a] font-bold">
                    Structured 8-Week Blueprint
                  </span>
                  <h4 className="font-cinzel text-xl sm:text-2xl font-bold text-[#eee7dc] mt-1">
                    Masterclass Curriculum
                  </h4>
                </div>
                <div className="hidden sm:flex items-center gap-2 text-xs text-[#a99e90] bg-[#16130f] px-3 py-1.5 rounded-lg border border-[#d6b17a]/20">
                  <Clock className="w-3.5 h-3.5 text-[#d6b17a]" />
                  <span>Beginner to Pro</span>
                </div>
              </div>

              {/* Module Selector Buttons */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-6">
                {course.curriculum.map((mod, idx) => (
                  <button
                    key={mod.number}
                    onClick={() => setActiveTab(idx)}
                    className={`p-3 rounded-lg text-left transition-all cursor-pointer border ${
                      activeTab === idx
                        ? 'bg-[#261f16] border-[#f0d29b] text-[#fcedc9] shadow-md'
                        : 'bg-[#14120e] border-[#d6b17a]/10 text-[#8e8274] hover:text-[#ddd2c5] hover:border-[#d6b17a]/30'
                    }`}
                  >
                    <div className="text-[10px] font-mono-nums text-[#d6b17a] font-bold uppercase">
                      Module {mod.number}
                    </div>
                    <div className="text-xs font-semibold truncate mt-0.5">
                      {mod.duration}
                    </div>
                  </button>
                ))}
              </div>

              {/* Active Module Details */}
              <div className="p-5 rounded-xl bg-[#13110d] border border-[#d6b17a]/25 space-y-4 mb-6">
                <div className="flex items-center justify-between">
                  <h5 className="font-bold text-base sm:text-lg text-[#f7f2ea] font-jakarta">
                    {course.curriculum[activeTab].title}
                  </h5>
                  <span className="text-xs font-mono-nums text-[#f0d29b] bg-[#d6b17a]/15 px-2.5 py-1 rounded border border-[#d6b17a]/30">
                    {course.curriculum[activeTab].duration}
                  </span>
                </div>

                <div className="space-y-2.5">
                  {course.curriculum[activeTab].highlights.map((item, i) => (
                    <div key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-[#c8bcad]">
                      <Target className="w-4 h-4 text-[#d6b17a] shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* The Math Behind $150 Value */}
              <div className="p-4 rounded-xl bg-[#1b1712]/90 border border-[#f0d29b]/25 flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-lg bg-[#d6b17a]/20 border border-[#d6b17a]/40 flex items-center justify-center shrink-0 text-[#f0d29b]">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h6 className="text-xs sm:text-sm font-bold text-[#f5e4c3] mb-0.5">
                    Why the $150 investment pays for itself
                  </h6>
                  <p className="text-xs text-[#a19688] leading-relaxed">
                    On a $10,000 funded account, risking just 1% ($100) on a single 1:3 RR setup yields <strong>$300 profit</strong>. One single disciplined trade covers your entire $150 mentorship fee twice over.
                  </p>
                </div>
              </div>

            </div>

            {/* Quick footer guarantee */}
            <div className="pt-6 border-t border-[#d6b17a]/15 mt-6 flex flex-wrap items-center justify-between gap-3 text-xs text-[#8e8273]">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#d6b17a]" />
                <span>Verified Content • Zero Indicator Clutter</span>
              </span>
              <button
                onClick={onOpenEnrollModal}
                className="text-[#f0d29b] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
              >
                <span>Ask about enrollment</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
