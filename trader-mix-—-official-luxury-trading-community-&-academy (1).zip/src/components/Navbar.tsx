import React, { useState } from 'react';
import { Home, BookOpen, Headphones, Users, ChevronDown, Globe, LogIn, UserPlus, Menu, X } from 'lucide-react';
import { BrandLogo } from './BrandLogo';
import { TRADER_MIX_DATA } from '../data/traderData';

interface NavbarProps {
  onOpenEnrollModal: () => void;
  onOpenAuthModal: (mode: 'login' | 'signup') => void;
  onOpenCommunityModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  onOpenEnrollModal, 
  onOpenAuthModal, 
  onOpenCommunityModal 
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const [currentLang, setCurrentLang] = useState<'EN' | 'BN'>('EN');

  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-xl bg-[#0a0907]/90 border-b border-[#ffc107]/20 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-4">
          
          {/* Left: Brand Logo with Crown */}
          <a href="#" className="flex items-center gap-2 shrink-0 focus:outline-none">
            <BrandLogo size="sm" showSubtitle={true} />
          </a>

          {/* Center Navigation Pill Bar (Exact styling from sample mockup) */}
          <nav className="hidden lg:flex items-center gap-1.5 p-1.5 rounded-full bg-[#181510]/95 border border-[#ffc107]/30 shadow-lg">
            <a 
              href="#home" 
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#2a2215] text-[#FFDE59] text-xs font-bold transition-all shadow-sm"
            >
              <Home className="w-3.5 h-3.5 text-[#FFDE59]" />
              <span>Home</span>
            </a>

            <a 
              href="#course" 
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-[#E2E8F0] hover:text-[#FFDE59] text-xs font-semibold transition-all hover:bg-[#221c13]"
            >
              <BookOpen className="w-3.5 h-3.5 text-[#ffc107]" />
              <span>Courses & Services</span>
              <ChevronDown className="w-3 h-3 opacity-70" />
            </a>

            <a 
              href="#contact" 
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-[#E2E8F0] hover:text-[#FFDE59] text-xs font-semibold transition-all hover:bg-[#221c13]"
            >
              <Headphones className="w-3.5 h-3.5 text-[#ffc107]" />
              <span>Contact Us</span>
            </a>

            <button 
              onClick={onOpenCommunityModal}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-full btn-sample-yellow text-xs font-extrabold cursor-pointer"
            >
              <Users className="w-3.5 h-3.5 text-[#0d0a06]" />
              <span>Join Our Community</span>
            </button>
          </nav>

          {/* Right: Language + Log In + Sign Up */}
          <div className="hidden sm:flex items-center gap-2.5 shrink-0">
            {/* Language dropdown */}
            <div className="relative">
              <button
                onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#181510] border border-[#ffc107]/25 text-xs text-[#E2E8F0] hover:border-[#ffc107] transition-all cursor-pointer"
              >
                <Globe className="w-3.5 h-3.5 text-[#ffc107]" />
                <span className="font-bold">{currentLang}</span>
                <ChevronDown className="w-3 h-3 opacity-70" />
              </button>

              {langDropdownOpen && (
                <div className="absolute right-0 mt-1 w-24 rounded-lg bg-[#181510] border border-[#ffc107]/40 p-1 shadow-xl z-50">
                  <button
                    onClick={() => { setCurrentLang('EN'); setLangDropdownOpen(false); }}
                    className={`w-full text-left px-2 py-1 text-xs rounded font-bold ${currentLang === 'EN' ? 'bg-[#ffc107]/20 text-[#ffc107]' : 'text-white'}`}
                  >
                    English
                  </button>
                  <button
                    onClick={() => { setCurrentLang('BN'); setLangDropdownOpen(false); }}
                    className={`w-full text-left px-2 py-1 text-xs rounded font-bold ${currentLang === 'BN' ? 'bg-[#ffc107]/20 text-[#ffc107]' : 'text-white'}`}
                  >
                    বাংলা
                  </button>
                </div>
              )}
            </div>

            {/* Log In */}
            <button
              onClick={() => onOpenAuthModal('login')}
              className="px-3.5 py-1.5 text-xs font-semibold text-[#E2E8F0] hover:text-white transition-colors cursor-pointer"
            >
              Log In
            </button>

            {/* Sign Up with Gold border */}
            <button
              onClick={() => onOpenAuthModal('signup')}
              className="px-4 py-1.5 text-xs font-bold text-[#FFDE59] bg-[#1a1610] border border-[#ffc107]/60 rounded-lg hover:border-[#FFDE59] hover:bg-[#292218] transition-all cursor-pointer shadow-sm"
            >
              Sign Up
            </button>
          </div>

          {/* Mobile menu trigger */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={() => onOpenCommunityModal()}
              className="px-3 py-1 text-xs font-bold btn-sample-yellow"
            >
              Join
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#ffc107] rounded-lg bg-[#181510] border border-[#ffc107]/30"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-[#ffc107]/30 bg-[#0e0c09]/98 backdrop-blur-2xl px-6 py-6 space-y-4">
          <div className="flex flex-col space-y-3 text-sm font-medium">
            <a 
              href="#home" 
              onClick={() => setMobileMenuOpen(false)}
              className="text-[#FFDE59] font-bold py-1 flex items-center gap-2"
            >
              <Home className="w-4 h-4 text-[#FFDE59]" />
              <span>Home</span>
            </a>
            <a 
              href="#course" 
              onClick={() => setMobileMenuOpen(false)}
              className="text-white hover:text-[#FFDE59] py-1 flex items-center gap-2"
            >
              <BookOpen className="w-4 h-4 text-[#ffc107]" />
              <span>Courses & Services ($150)</span>
            </a>
            <a 
              href="#contact" 
              onClick={() => setMobileMenuOpen(false)}
              className="text-white hover:text-[#FFDE59] py-1 flex items-center gap-2"
            >
              <Headphones className="w-4 h-4 text-[#ffc107]" />
              <span>Contact Us</span>
            </a>
          </div>

          <div className="pt-4 border-t border-[#ffc107]/20 flex flex-col gap-2.5">
            <button
              onClick={() => { setMobileMenuOpen(false); onOpenCommunityModal(); }}
              className="w-full py-2.5 text-center text-xs font-bold btn-sample-yellow flex items-center justify-center gap-2"
            >
              <Users className="w-4 h-4" />
              <span>Join Our Community</span>
            </button>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => { setMobileMenuOpen(false); onOpenAuthModal('login'); }}
                className="py-2 text-xs font-semibold text-white bg-[#1a1610] border border-[#ffc107]/30 rounded-lg text-center"
              >
                Log In
              </button>
              <button
                onClick={() => { setMobileMenuOpen(false); onOpenAuthModal('signup'); }}
                className="py-2 text-xs font-bold text-[#FFDE59] bg-[#292218] border border-[#ffc107] rounded-lg text-center"
              >
                Sign Up
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
