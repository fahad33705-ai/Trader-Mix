import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { TRADER_MIX_DATA } from '../data/traderData';

interface CommunitySectionProps {
  onOpenEnrollModal: () => void;
}

export const CommunitySection: React.FC<CommunitySectionProps> = ({ onOpenEnrollModal: _onOpenEnrollModal }) => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const toggleFaq = (idx: number) => {
    setOpenFaq(openFaq === idx ? null : idx);
  };

  return (
    <section id="community" className="relative py-20 lg:py-24 bg-[#0d0b09] border-t border-[#d6b17a]/15 overflow-hidden">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* FAQ Section Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1e1812] border border-[#d6b17a]/30 text-xs text-[#f0d29b] font-bold tracking-[0.2em] uppercase mb-3">
            <HelpCircle className="w-3.5 h-3.5 text-[#f0d29b]" />
            <span>Trader Mix Knowledge Base</span>
          </div>

          <h2 className="font-cinzel text-3xl sm:text-4xl font-bold text-[#eee7dc] mb-3">
            Frequently Asked <span className="text-gold-gradient">Questions</span>
          </h2>

          <p className="font-jakarta text-[#a89d90] text-xs sm:text-sm max-w-xl mx-auto leading-relaxed">
            Everything you need to know about our trading education, $150 mentorship enrollment, and free community resources.
          </p>
        </div>

          <div className="space-y-3">
            {TRADER_MIX_DATA.faqs.map((faq, idx) => (
              <div
                key={idx}
                className="glass-panel rounded-xl overflow-hidden border border-[#d6b17a]/20 transition-all"
              >
                <button
                  type="button"
                  onClick={() => toggleFaq(idx)}
                  className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 cursor-pointer focus:outline-none"
                >
                  <span className="font-bold text-sm sm:text-base text-[#f7f2ea] font-jakarta">
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-[#f0d29b] shrink-0 transition-transform duration-300 ${
                      openFaq === idx ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {openFaq === idx && (
                  <div className="px-4 pb-4 sm:px-5 sm:pb-5 pt-0 text-xs sm:text-sm text-[#b8ada0] leading-relaxed border-t border-[#d6b17a]/10 font-jakarta">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
      </div>
    </section>
  );
};
