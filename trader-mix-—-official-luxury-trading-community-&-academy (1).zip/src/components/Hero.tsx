import React from 'react';
import { ArrowUpRight, TrendingUp, ShieldCheck, Award, Users, CheckCircle2, DollarSign } from 'lucide-react';
import { TRADER_MIX_DATA } from '../data/traderData';

interface HeroProps {
  onOpenEnrollModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenEnrollModal }) => {
  return (
    <section id="home" className="relative pt-8 pb-16 lg:pt-14 lg:pb-24 overflow-hidden">
      {/* Background with luxury penthouse image and moody ambient overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src={TRADER_MIX_DATA.brand.heroImage}
          alt="Trader Mix Luxury Interior"
          className="w-full h-full object-cover object-center brightness-[0.38] contrast-[1.08] filter"
          referrerPolicy="no-referrer"
        />
        {/* Soft radial golden spotlight from the ceiling lights */}
        <div className="absolute inset-0 bg-radial from-[#d6b17a]/15 via-transparent to-[#0b0a09]/95 pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0b0a09]/80 via-transparent to-[#0b0a09] pointer-events-none" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Eyebrow & VIP status notification */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1e1913]/90 border border-[#d6b17a]/35 shadow-[0_2px_12px_rgba(214,177,122,0.18)]">
            <span className="w-2 h-2 rounded-full bg-[#f0d29b] shadow-[0_0_6px_#f0d29b]"></span>
            <span className="text-[11px] font-semibold tracking-[0.2em] text-gold-subtle uppercase">
              Official Trader Mix Community
            </span>
          </div>

          <div 
            onClick={onOpenEnrollModal}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#271f15]/90 border border-[#f0d29b]/40 text-[#fcedc9] text-xs font-medium cursor-pointer hover:border-[#f0d29b] transition-all"
          >
            <span className="text-[#f0d29b] font-bold font-mono-nums">$150</span>
            <span>Complete Course & VIP Signals Enrollment Open</span>
            <ArrowUpRight className="w-3 h-3 text-[#f0d29b]" />
          </div>
        </div>

        {/* Main Hero Header */}
        <div className="text-center max-w-4xl mx-auto mb-10">
          <h1 className="font-cinzel text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight leading-[1.08] text-[#f7f2ea] mb-6">
            Learn Trading.
            <br />
            <span className="text-gold-gradient font-black">
              Build Your Future.
            </span>
          </h1>

          <p className="font-jakarta text-base sm:text-lg lg:text-xl text-[#d4c9bc] max-w-2xl mx-auto leading-relaxed font-normal mb-8">
            Connect with our elite trading community for institutional price action, 
            disciplined risk management, and the <span className="text-[#f0d29b] font-semibold">$150 Complete Masterclass</span> mentored directly by <span className="text-white font-semibold">Shaheen</span>.
          </p>

          {/* Primary CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={onOpenEnrollModal}
              className="w-full sm:w-auto px-8 py-3.5 text-sm sm:text-base font-bold text-[#14100b] bg-gradient-to-r from-[#f0d29b] via-[#e2b774] to-[#c79b61] rounded-lg hover:brightness-110 active:scale-[0.98] transition-all shadow-[0_8px_25px_rgba(214,177,122,0.35)] flex items-center justify-center gap-2 cursor-pointer"
            >
              <DollarSign className="w-4 h-4 text-[#14100b] stroke-[3]" />
              <span>Enroll In $150 Masterclass</span>
              <span className="text-xs bg-[#14100b]/20 px-2 py-0.5 rounded text-[#14100b]">
                Save 70%
              </span>
            </button>

            <a
              href={TRADER_MIX_DATA.platforms[0].url}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-7 py-3.5 text-sm sm:text-base font-semibold text-[#f0d29b] bg-[#1a1612]/90 border border-[#d6b17a]/40 rounded-lg hover:bg-[#282017] hover:border-[#f0d29b] transition-all flex items-center justify-center gap-2 shadow-lg"
            >
              <span>Join Public Telegram Channel</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>
          </div>

          {/* Trust badges */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-y-2 gap-x-6 text-xs text-[#a99e90]">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-[#d6b17a]" />
              <span>Pure Price Action & SMC</span>
            </span>
            <span className="text-[#5b5145]">•</span>
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#d6b17a]" />
              <span>Strict 1:3 Risk/Reward Strategy</span>
            </span>
            <span className="text-[#5b5145]">•</span>
            <span className="flex items-center gap-1.5">
              <Award className="w-4 h-4 text-[#d6b17a]" />
              <span>4 Active Social Channels</span>
            </span>
          </div>
        </div>

        {/* Live Market Bar */}
        <div className="glass-panel rounded-xl p-4 sm:p-5 max-w-5xl mx-auto border border-[#d6b17a]/25 shadow-2xl">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#d6b17a]/15 text-xs text-[#a09485]">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="font-semibold uppercase tracking-wider text-[#d4c8b8]">
                Institutional Watchlist
              </span>
            </div>
            <span className="text-[11px] text-[#8e8274] hidden sm:inline">
              Live market volatility reference • 1:3 Risk Model
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {TRADER_MIX_DATA.marketAssets.map((asset) => (
              <div
                key={asset.symbol}
                className="bg-[#12100d]/80 rounded-lg p-2.5 sm:p-3 border border-[#d6b17a]/10 hover:border-[#d6b17a]/35 transition-all"
              >
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-bold text-[#f7f2eb] font-jakarta">{asset.symbol}</span>
                  <span
                    className={`font-mono-nums text-[11px] font-semibold ${
                      asset.isPositive ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {asset.change}
                  </span>
                </div>
                <div className="text-sm sm:text-base font-mono-nums font-bold text-gold-subtle">
                  {asset.price}
                </div>
                <div className="text-[10px] text-[#7d7162] truncate mt-0.5 font-jakarta">
                  {asset.name}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
