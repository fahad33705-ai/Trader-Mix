import React, { useState } from 'react';
import { Calculator, ShieldCheck, TrendingUp, Sparkles, AlertCircle } from 'lucide-react';

interface TradingCalculatorProps {
  onOpenEnrollModal: () => void;
}

export const TradingCalculator: React.FC<TradingCalculatorProps> = ({ onOpenEnrollModal }) => {
  const [accountSize, setAccountSize] = useState<number>(10000);
  const [riskPercent, setRiskPercent] = useState<number>(1.0);
  const [stopLossPips, setStopLossPips] = useState<number>(25);
  const [riskReward, setRiskReward] = useState<number>(3); // 1:3 ratio

  // Math calculations
  const riskAmount = (accountSize * riskPercent) / 100;
  // Standard pip value estimate ($10 per lot for 1 standard lot on EURUSD/Gold)
  const pipValuePerLot = 10;
  const calculatedLotSize = Math.max(0.01, Number((riskAmount / (stopLossPips * pipValuePerLot)).toFixed(2)));
  const targetProfit = riskAmount * riskReward;
  const courseCostRatio = (targetProfit / 150).toFixed(1);

  return (
    <section id="calculator" className="relative py-20 lg:py-28 bg-[#0b0a09] overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1e1812] border border-[#d6b17a]/30 text-xs text-[#f0d29b] font-bold tracking-[0.2em] uppercase mb-3">
            <Calculator className="w-3.5 h-3.5 text-[#f0d29b]" />
            <span>Interactive Risk Engine</span>
          </div>

          <h2 className="font-cinzel text-3xl sm:text-5xl font-bold text-[#f7f2ea] mb-4">
            Institutional <span className="text-gold-gradient">Position Size Calculator</span>
          </h2>

          <p className="font-jakarta text-[#b8ada0] text-sm sm:text-base leading-relaxed">
            See the exact mathematics of how a strict 1:3 Risk-to-Reward framework turns consistency into wealth, and how a single disciplined trade covers your <span className="text-[#f0d29b] font-bold font-mono-nums">$150 course</span>.
          </p>
        </div>

        {/* Calculator Widget Split */}
        <div className="glass-panel rounded-2xl p-6 sm:p-10 max-w-5xl mx-auto border-2 border-[#d6b17a]/30 shadow-2xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Controls Column */}
          <div className="lg:col-span-6 space-y-6">
            
            {/* Account Size Selection */}
            <div>
              <div className="flex justify-between items-center text-xs mb-2 text-[#d4c8b8]">
                <label className="font-semibold uppercase tracking-wider">Account Balance ($)</label>
                <span className="font-mono-nums font-bold text-[#f0d29b] text-sm">
                  ${accountSize.toLocaleString()}
                </span>
              </div>
              
              <div className="grid grid-cols-4 gap-2 mb-3">
                {[1000, 5000, 10000, 50000].map((size) => (
                  <button
                    key={size}
                    type="button"
                    onClick={() => setAccountSize(size)}
                    className={`py-1.5 px-2 rounded-md text-xs font-mono-nums font-semibold transition-all cursor-pointer ${
                      accountSize === size
                        ? 'bg-[#f0d29b] text-[#14100b] shadow-md font-bold'
                        : 'bg-[#181410] text-[#9d9284] border border-[#d6b17a]/20 hover:text-white'
                    }`}
                  >
                    ${size >= 1000 ? `${size / 1000}k` : size}
                  </button>
                ))}
              </div>

              <input
                type="range"
                min="500"
                max="100000"
                step="500"
                value={accountSize}
                onChange={(e) => setAccountSize(Number(e.target.value))}
                className="w-full h-1.5 bg-[#251e17] rounded-lg appearance-none cursor-pointer accent-[#f0d29b]"
              />
            </div>

            {/* Risk Percentage Slider */}
            <div>
              <div className="flex justify-between items-center text-xs mb-2 text-[#d4c8b8]">
                <label className="font-semibold uppercase tracking-wider">Risk Per Trade (%)</label>
                <span className="font-mono-nums font-bold text-[#f0d29b] text-sm">
                  {riskPercent}% (${riskAmount.toFixed(0)})
                </span>
              </div>
              <input
                type="range"
                min="0.25"
                max="3.0"
                step="0.25"
                value={riskPercent}
                onChange={(e) => setRiskPercent(Number(e.target.value))}
                className="w-full h-1.5 bg-[#251e17] rounded-lg appearance-none cursor-pointer accent-[#f0d29b]"
              />
              <div className="flex justify-between text-[10px] text-[#7d7162] mt-1 font-mono-nums">
                <span>0.25% (Conservative)</span>
                <span>1.0% (Trader Mix Standard)</span>
                <span>3.0% (Max)</span>
              </div>
            </div>

            {/* Stop Loss Pips */}
            <div>
              <div className="flex justify-between items-center text-xs mb-2 text-[#d4c8b8]">
                <label className="font-semibold uppercase tracking-wider">Stop Loss (Pips)</label>
                <span className="font-mono-nums font-bold text-[#f0d29b] text-sm">
                  {stopLossPips} Pips
                </span>
              </div>
              <input
                type="range"
                min="10"
                max="80"
                step="1"
                value={stopLossPips}
                onChange={(e) => setStopLossPips(Number(e.target.value))}
                className="w-full h-1.5 bg-[#251e17] rounded-lg appearance-none cursor-pointer accent-[#f0d29b]"
              />
            </div>

            {/* Target Risk-Reward Ratio */}
            <div>
              <div className="flex justify-between items-center text-xs mb-2 text-[#d4c8b8]">
                <label className="font-semibold uppercase tracking-wider">Target Risk-to-Reward</label>
                <span className="font-mono-nums font-bold text-emerald-400 text-sm">
                  1:{riskReward} Ratio
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[2, 3, 4].map((rr) => (
                  <button
                    key={rr}
                    type="button"
                    onClick={() => setRiskReward(rr)}
                    className={`py-2 px-3 rounded-lg text-xs font-mono-nums font-bold transition-all cursor-pointer border ${
                      riskReward === rr
                        ? 'bg-[#292218] border-[#f0d29b] text-[#fcedc9]'
                        : 'bg-[#15120e] border-[#d6b17a]/15 text-[#8e8273] hover:text-[#f7f2ea]'
                    }`}
                  >
                    1:{rr} {rr === 3 ? '(Recommended)' : ''}
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Results Summary Display */}
          <div className="lg:col-span-6 bg-[#12100d]/95 rounded-xl p-6 sm:p-7 border border-[#d6b17a]/30 flex flex-col justify-between space-y-6 shadow-inner">
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#d6b17a]/20">
                <span className="text-xs uppercase font-bold text-[#d6b17a] tracking-wider">
                  Calculation Summary
                </span>
                <span className="text-[11px] text-[#8e8273] font-mono-nums">
                  Account: ${accountSize.toLocaleString()}
                </span>
              </div>

              {/* Major Calculated Output */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 rounded-lg bg-[#191510] border border-[#d6b17a]/15">
                  <div className="text-[10px] text-[#9d9284] uppercase tracking-wide">
                    Recommended Lot Size
                  </div>
                  <div className="text-2xl sm:text-3xl font-mono-nums font-black text-gold-gradient mt-1">
                    {calculatedLotSize}
                  </div>
                  <div className="text-[10px] text-[#7d7162]">Standard Lots</div>
                </div>

                <div className="p-3 rounded-lg bg-[#191510] border border-[#d6b17a]/15">
                  <div className="text-[10px] text-[#9d9284] uppercase tracking-wide">
                    Capital At Risk (1R)
                  </div>
                  <div className="text-2xl sm:text-3xl font-mono-nums font-black text-rose-400 mt-1">
                    ${riskAmount.toFixed(0)}
                  </div>
                  <div className="text-[10px] text-[#7d7162]">Strict {riskPercent}% loss limit</div>
                </div>
              </div>

              {/* Profit on Target */}
              <div className="p-4 rounded-xl bg-gradient-to-br from-[#1a231b] to-[#121913] border border-emerald-500/40">
                <div className="flex items-center justify-between text-xs text-emerald-300 font-semibold mb-1">
                  <span className="flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                    <span>Projected Profit (1:{riskReward} Target)</span>
                  </span>
                  <span className="font-mono-nums text-emerald-400 font-bold">
                    +{(riskPercent * riskReward).toFixed(1)}% Gain
                  </span>
                </div>
                <div className="text-3xl sm:text-4xl font-mono-nums font-extrabold text-emerald-400">
                  +${targetProfit.toFixed(0)}
                </div>
              </div>

              {/* ROI on Course Note */}
              <div className="p-3.5 rounded-lg bg-[#221c14] border border-[#f0d29b]/30 text-xs text-[#f5e4c3] flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#f0d29b] shrink-0" />
                  <span>
                    This 1 trade covers the <strong>$150 Masterclass</strong> by <strong>{courseCostRatio}x</strong>!
                  </span>
                </div>
              </div>
            </div>

            {/* CTA */}
            <button
              onClick={onOpenEnrollModal}
              className="w-full py-3.5 rounded-lg bg-gradient-to-r from-[#f0d29b] to-[#c79b61] text-[#14100b] font-bold text-xs sm:text-sm hover:brightness-110 active:scale-95 transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Learn This Exact Setup for $150</span>
            </button>
          </div>

        </div>

      </div>
    </section>
  );
};
