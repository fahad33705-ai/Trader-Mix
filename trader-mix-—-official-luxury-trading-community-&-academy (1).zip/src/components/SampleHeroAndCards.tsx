import React, { useState } from 'react';
import { ArrowRight, GraduationCap, TrendingUp, AlertTriangle } from 'lucide-react';
import { BrandLogo } from './BrandLogo';
import { TRADER_MIX_DATA } from '../data/traderData';

interface SampleHeroAndCardsProps {
  onOpenEnrollModal: () => void;
  onOpenCommunityModal: () => void;
}

export const SampleHeroAndCards: React.FC<SampleHeroAndCardsProps> = ({ 
  onOpenEnrollModal, 
  onOpenCommunityModal 
}) => {
  return (
    <section className="relative pt-6 pb-12 lg:pt-10 lg:pb-16 overflow-hidden">
      
      {/* Background using the user's luxury room image (Gemini_Generated_Image_4gmyfh4gmyfh4gmy_e3c72258.jpg) */}
      <div className="absolute inset-0 z-0">
        <img
          src={TRADER_MIX_DATA.brand.heroImage}
          alt="Trader Mix Penthouse Lounge"
          className="w-full h-full object-cover object-center brightness-[0.35] contrast-[1.12]"
          referrerPolicy="no-referrer"
        />
        {/* Dark vignette */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#070707]/90 via-[#0a0907]/60 to-[#070707] pointer-events-none" />
      </div>

      {/* Radiant Golden Horizontal Beam passing through the middle behind cards */}
      <div className="gold-beam top-[48%] z-10 hidden sm:block" />

      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Hero Welcome & Mega Title */}
        <div className="text-center max-w-4xl mx-auto mb-10 pt-2">
          <div className="text-lg sm:text-2xl font-bold tracking-wide text-white mb-1 font-sans">
            Welcome to
          </div>

          {/* Mega Brand Logo */}
          <div className="mb-4">
            <BrandLogo size="hero" showSubtitle={true} />
          </div>

          {/* Subtitle tag line in italic style */}
          <p className="text-sm sm:text-lg text-[#F1F5F9] italic font-medium tracking-wide drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] mb-6">
            Join our community and take your trading skills to the next level
          </p>

          {/* Telegram Public Channel Pill Button */}
          <div className="flex justify-center">
            <a
              href={TRADER_MIX_DATA.platforms[0].url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 px-6 py-2.5 rounded-full bg-[#14120e]/95 border-2 border-[#FFC72C] hover:border-[#FFE082] shadow-[0_0_25px_rgba(255,199,44,0.5)] hover:shadow-[0_0_35px_rgba(255,199,44,0.7)] hover:scale-105 transition-all group cursor-pointer"
            >
              {/* Telegram Circular Icon */}
              <div className="w-7 h-7 rounded-full bg-[#FFC72C] flex items-center justify-center text-[#14120e] shadow-md group-hover:scale-110 transition-transform">
                <svg className="w-4 h-4 fill-current ml-0.5" viewBox="0 0 24 24">
                  <path d="M21.7 3.3 18.5 20c-.2 1.2-.9 1.5-1.8 1l-5-3.7-2.4 2.3c-.3.3-.5.5-1 .5l.4-5.1 9.3-8.4c.4-.4-.1-.6-.6-.2L6 13.7 1.1 12.2c-1.1-.3-1.1-1.1.2-1.6L20.4 3.2c.9-.3 1.7.2 1.3 1.1Z"/>
                </svg>
              </div>

              <span className="text-sm sm:text-base font-extrabold text-[#38BDF8] tracking-wide group-hover:text-[#7DD3FC]">
                Telegram Public Channel
              </span>
            </a>
          </div>
        </div>

        {/* 3 Prominent Cards Grid (Trading Investing removed per user request) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 lg:gap-6 mb-14">
          
          {/* Card 1: Forex Trading - Premium Course ($150) */}
          <div className="sample-card p-6 flex flex-col justify-between">
            <div>
              {/* Top Row: Avatar on Left + Title & Badge on Right */}
              <div className="flex items-start gap-4 mb-4">
                {/* Shaheen Portrait in gold circle */}
                <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-[#FFC72C] shrink-0 shadow-[0_0_18px_rgba(255,199,44,0.55)] bg-[#1e1912]">
                  <img
                    src={TRADER_MIX_DATA.brand.founderPhotoMain}
                    alt="Shaheen Forex Masterclass"
                    className="w-full h-full object-cover object-top"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="flex-1">
                  <h3 className="font-extrabold text-2xl leading-tight mb-2">
                    <span className="text-[#FFC72C] block">Forex</span>
                    <span className="text-white block">Trading</span>
                  </h3>
                  <span className="inline-block px-3 py-0.5 rounded-full border border-[#FFC72C] text-[#FFDE59] text-[10px] font-bold uppercase tracking-wider bg-[#261f12]/60">
                    Premium Course
                  </span>
                </div>
              </div>

              {/* Description line with Graduation Cap */}
              <div className="flex items-center gap-2.5 text-xs sm:text-sm text-[#E2E8F0] mb-6 font-jakarta leading-snug">
                <GraduationCap className="w-4 h-4 text-[#FFC72C] shrink-0" />
                <span>Beginner to Advanced Trading Masterclass</span>
              </div>
            </div>

            {/* Bottom Row: Price ($150) + Yellow Button (Enroll Now ➔) */}
            <div className="flex items-center justify-between gap-2 pt-3 border-t border-[#ffc107]/20">
              <div className="flex items-center gap-2">
                <span className="px-3.5 py-1 rounded-full bg-[#2a2215] border border-[#FFC72C] text-[#FFDE59] font-mono-nums font-black text-base shadow-inner">
                  ${TRADER_MIX_DATA.course.price}
                </span>
                <span className="text-xs text-[#94A3B8] line-through font-mono-nums">
                  $250
                </span>
              </div>

              <button
                onClick={onOpenEnrollModal}
                className="px-5 py-2.5 text-xs font-black btn-sample-yellow flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <span>Enroll Now</span>
                <ArrowRight className="w-3.5 h-3.5 stroke-[3]" />
              </button>
            </div>
          </div>

          {/* Card 2: Premium Live Trade - Everyday with User's Uploaded Circular Badge */}
          <div className="sample-card p-6 flex flex-col justify-between border-2 border-[#22c55e]/50 shadow-[0_0_25px_rgba(34,197,94,0.15)]">
            <div>
              {/* Top Row: User's Uploaded Binary Trading Badge + Title */}
              <div className="flex items-start gap-4 mb-4">
                <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-[#22c55e] shrink-0 shadow-[0_0_20px_rgba(34,197,94,0.7)] bg-[#041006] relative group">
                  <img
                    src={TRADER_MIX_DATA.brand.liveTradeLogo}
                    alt="TraderMix Binary Live Trade by Shaheen"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="flex-1">
                  <h3 className="font-extrabold text-2xl leading-tight mb-2">
                    <span className="text-[#22c55e] block">Premium</span>
                    <span className="text-white block">Live Trade</span>
                  </h3>
                  <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-[#15803d]/40 border border-[#22c55e] text-[#86efac] text-[10px] font-bold uppercase tracking-wider">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#22c55e] animate-pulse"></span>
                    <span>Everyday</span>
                  </span>
                </div>
              </div>

              {/* Description line with Growth Chart */}
              <div className="flex items-center gap-2.5 text-xs sm:text-sm text-[#E2E8F0] mb-6 font-jakarta leading-snug">
                <TrendingUp className="w-4 h-4 text-[#22c55e] shrink-0" />
                <span>Premium Live Trade Support with Expert Guidance</span>
              </div>
            </div>

            {/* Bottom Row: Free Badge + Green Button (Join Telegram ➔) */}
            <div className="flex items-center justify-between gap-2 pt-3 border-t border-[#22c55e]/25">
              <span className="px-3.5 py-1 rounded-full bg-[#0d2815] border border-[#22c55e] text-[#86efac] font-bold text-xs">
                Free
              </span>

              <a
                href={TRADER_MIX_DATA.platforms[0].url}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-2.5 text-xs font-black btn-sample-green flex items-center gap-1.5 shadow-md"
              >
                <span>Join Telegram</span>
                <ArrowRight className="w-3.5 h-3.5 stroke-[3]" />
              </a>
            </div>
          </div>

          {/* Card 3: Join Our Community + 3D Golden Rising Chart */}
          <div className="sample-card p-6 flex flex-col justify-between">
            <div>
              {/* Header with Title & Rising 3D Chart graphic */}
              <div className="flex items-start justify-between gap-2 mb-3">
                <div>
                  <h3 className="font-extrabold text-2xl leading-tight">
                    <span className="text-white block">Join Our</span>
                    <span className="text-[#FFC72C] block">Community</span>
                  </h3>
                  <div className="text-xs text-[#CBD5E1] mt-1 font-jakarta font-medium">
                    Be a Part of Trader Mix Family
                  </div>
                </div>

                {/* Golden Ascending Bar Chart with Arrow graphic (from sample mockup) */}
                <div className="w-16 h-14 relative shrink-0">
                  <svg className="w-full h-full" viewBox="0 0 60 50" fill="none">
                    <rect x="5" y="35" width="8" height="15" rx="1.5" fill="url(#goldGrad)" />
                    <rect x="18" y="25" width="8" height="25" rx="1.5" fill="url(#goldGrad)" />
                    <rect x="31" y="15" width="8" height="35" rx="1.5" fill="url(#goldGrad)" />
                    <rect x="44" y="5" width="8" height="45" rx="1.5" fill="url(#goldGrad)" />
                    <path d="M4 42 Q 25 25, 48 8" stroke="#FFE082" strokeWidth="3" strokeLinecap="round" />
                    <polygon points="54,6 44,4 47,14" fill="#FFE082" />
                    <defs>
                      <linearGradient id="goldGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#FFE082" />
                        <stop offset="50%" stopColor="#FFC107" />
                        <stop offset="100%" stopColor="#FF8F00" />
                      </linearGradient>
                    </defs>
                  </svg>
                </div>
              </div>

              {/* 4 Social Icons Row */}
              <div className="flex items-center justify-between gap-2.5 my-6 px-1">
                {/* Telegram (Cyan) */}
                <a
                  href={TRADER_MIX_DATA.platforms[0].url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-11 h-11 rounded-xl bg-[#0088cc] flex items-center justify-center text-white shadow-md hover:scale-110 transition-transform"
                  title="Telegram Channel"
                >
                  <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                    <path d="M21.7 3.3 18.5 20c-.2 1.2-.9 1.5-1.8 1l-5-3.7-2.4 2.3c-.3.3-.5.5-1 .5l.4-5.1 9.3-8.4c.4-.4-.1-.6-.6-.2L6 13.7 1.1 12.2c-1.1-.3-1.1-1.1.2-1.6L20.4 3.2c.9-.3 1.7.2 1.3 1.1Z"/>
                  </svg>
                </a>

                {/* Facebook (Royal Blue) */}
                <a
                  href={TRADER_MIX_DATA.platforms[1].url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-11 h-11 rounded-xl bg-[#1877F2] flex items-center justify-center text-white shadow-md hover:scale-110 transition-transform"
                  title="Facebook Page"
                >
                  <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                    <path d="M13.5 21v-8h2.7l.4-3.1h-3.1v-2c0-.9.3-1.5 1.6-1.5h1.7V3.6c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3v2.1H7.3V13h2.8v8h3.4Z"/>
                  </svg>
                </a>

                {/* TikTok (Black/Neon) */}
                <a
                  href={TRADER_MIX_DATA.platforms[2].url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-11 h-11 rounded-xl bg-[#010101] border border-[#ff0050]/50 flex items-center justify-center text-white shadow-md hover:scale-110 transition-transform"
                  title="TikTok"
                >
                  <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                    <path d="M19.6 8.2a7.1 7.1 0 0 1-4.2-1.4v7.1a5.8 5.8 0 1 1-5-5.7v3.6a2.3 2.3 0 1 0 1.6 2.2V2.5h3.4c.2 2.1 1.9 3.8 4.2 4v1.7Z"/>
                  </svg>
                </a>

                {/* YouTube (Red) */}
                <a
                  href={TRADER_MIX_DATA.platforms[3].url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-11 h-11 rounded-xl bg-[#FF0000] flex items-center justify-center text-white shadow-md hover:scale-110 transition-transform"
                  title="YouTube Channel"
                >
                  <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                    <path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.6 12 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 0 0 .5 6.2 31 31 0 0 0 2.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1A31 31 0 0 0 24 12a31 31 0 0 0-.5-5.8ZM9.6 15.6V8.4l6.3 3.6-6.3 3.6Z"/>
                  </svg>
                </a>
              </div>
            </div>

            {/* Bottom Row: Follow Us ➔ Button */}
            <div className="pt-3 border-t border-[#ffc107]/20">
              <button
                onClick={onOpenCommunityModal}
                className="w-full py-2.5 text-xs font-black btn-sample-yellow flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
              >
                <span>Follow Us</span>
                <ArrowRight className="w-3.5 h-3.5 stroke-[3]" />
              </button>
            </div>
          </div>

        </div>

        {/* Bottom Bar matching sample mockup footer strip */}
        <div className="rounded-2xl p-4 sm:p-6 bg-[#0f0d0a]/95 border border-[#ffc107]/25 shadow-2xl flex flex-col lg:flex-row items-center justify-between gap-6">
          
          {/* Logo on Left */}
          <div className="shrink-0 flex items-center">
            <BrandLogo size="sm" showSubtitle={true} />
          </div>

          {/* Center text and risk notice */}
          <div className="flex-1 text-center lg:text-left px-0 lg:px-6 border-y lg:border-y-0 lg:border-x border-[#ffc107]/20 py-3 lg:py-0">
            <p className="text-xs sm:text-[13px] text-[#E2E8F0] leading-relaxed font-jakarta mb-2">
              We focus on helping every student grow in <strong className="text-[#FFC72C]">forex</strong> through step-by-step guidance, real market insights, and hands-on learning. Using modern strategies and smart risk management for <strong className="text-[#FFC72C]">long-term success</strong>.
            </p>
            <div className="flex items-center justify-center lg:justify-start gap-1.5 text-[11px] text-[#FBBF24] font-semibold">
              <AlertTriangle className="w-3.5 h-3.5 text-[#FBBF24] shrink-0" />
              <span>Trading involves financial risk. Always use proper risk management.</span>
              <AlertTriangle className="w-3.5 h-3.5 text-[#FBBF24] shrink-0" />
            </div>
          </div>

          {/* Right: 4 Circular social icons + "Learn • Grow • Succeed" signature */}
          <div className="shrink-0 flex flex-col items-center lg:items-end gap-2.5">
            <div className="flex items-center gap-2">
              <a href={TRADER_MIX_DATA.platforms[3].url} target="_blank" rel="noopener noreferrer" className="w-7 h-7 rounded-full bg-[#201a13] border border-[#ffc107]/30 flex items-center justify-center text-white hover:text-[#FFC72C] transition-colors">
                <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24"><path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.6 12 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 0 0 .5 6.2 31 31 0 0 0 0 12a31 31 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1A31 31 0 0 0 24 12a31 31 0 0 0-.5-5.8ZM9.6 15.6V8.4l6.3 3.6-6.3 3.6Z"/></svg>
              </a>
              <a href={TRADER_MIX_DATA.platforms[1].url} target="_blank" rel="noopener noreferrer" className="w-7 h-7 rounded-full bg-[#201a13] border border-[#ffc107]/30 flex items-center justify-center text-white hover:text-[#FFC72C] transition-colors">
                <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
              </a>
              <a href={TRADER_MIX_DATA.platforms[2].url} target="_blank" rel="noopener noreferrer" className="w-7 h-7 rounded-full bg-[#201a13] border border-[#ffc107]/30 flex items-center justify-center text-white hover:text-[#FFC72C] transition-colors">
                <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24"><path d="M19.6 8.2a7.1 7.1 0 0 1-4.2-1.4v7.1a5.8 5.8 0 1 1-5-5.7v3.6a2.3 2.3 0 1 0 1.6 2.2V2.5h3.4c.2 2.1 1.9 3.8 4.2 4v1.7Z"/></svg>
              </a>
              <a href={TRADER_MIX_DATA.platforms[1].url} target="_blank" rel="noopener noreferrer" className="w-7 h-7 rounded-full bg-[#201a13] border border-[#ffc107]/30 flex items-center justify-center text-white hover:text-[#FFC72C] transition-colors">
                <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24"><path d="M13.5 21v-8h2.7l.4-3.1h-3.1v-2c0-.9.3-1.5 1.6-1.5h1.7V3.6c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3v2.1H7.3V13h2.8v8h3.4Z"/></svg>
              </a>
            </div>

            <div className="text-right">
              <span className="font-serif italic text-sm sm:text-base text-brush-gold font-bold tracking-wide">
                Learn • Grow • Succeed
              </span>
              <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-[#FFC72C] to-transparent mt-0.5"></div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
