import React from 'react';
import { Award, ShieldCheck, TrendingUp, CheckCircle, Flame, Sparkles, MessageCircle } from 'lucide-react';
import { TRADER_MIX_DATA } from '../data/traderData';

interface FounderSectionProps {
  onOpenEnrollModal: () => void;
}

export const FounderSection: React.FC<FounderSectionProps> = ({ onOpenEnrollModal }) => {
  return (
    <section id="founder" className="relative py-20 lg:py-28 bg-[#0d0b09] border-t border-b border-[#d6b17a]/15 overflow-hidden">
      {/* Ambient background gold glow elements */}
      <div className="absolute top-1/4 -left-40 w-96 h-96 bg-[#d6b17a]/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 right-0 w-80 h-80 bg-[#c79b61]/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1e1913] border border-[#d6b17a]/25 text-xs text-[#f0d29b] font-semibold tracking-[0.2em] uppercase mb-3">
            <Award className="w-3.5 h-3.5 text-[#f0d29b]" />
            <span>Leadership & Mentorship</span>
          </div>
          <h2 className="font-cinzel text-3xl sm:text-5xl font-bold text-[#f7f2ea] mb-4">
            Meet <span className="text-gold-gradient">{TRADER_MIX_DATA.brand.founder}</span>
          </h2>
          <p className="font-jakarta text-[#b8ada0] text-sm sm:text-base leading-relaxed">
            The mind behind <span className="text-[#f0d29b] font-semibold">Trader Mix</span>. Dedicated to stripping away false internet hype and teaching traders how institutions actually move liquidity.
          </p>
        </div>

        {/* Master Portrait & Philosophy Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center mb-16">
          
          {/* Main Portrait Card (Dhaka Regency Luxury Style) */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden glass-panel border-2 border-[#d6b17a]/40 p-2 shadow-[0_20px_50px_rgba(0,0,0,0.6)] group">
              
              {/* Luxury Corner Ornaments */}
              <div className="absolute top-4 left-4 z-20 w-4 h-4 border-t-2 border-l-2 border-[#f0d29b]" />
              <div className="absolute top-4 right-4 z-20 w-4 h-4 border-t-2 border-r-2 border-[#f0d29b]" />
              <div className="absolute bottom-4 left-4 z-20 w-4 h-4 border-b-2 border-l-2 border-[#f0d29b]" />
              <div className="absolute bottom-4 right-4 z-20 w-4 h-4 border-b-2 border-r-2 border-[#f0d29b]" />

              <div className="relative aspect-[3/4] w-full rounded-xl overflow-hidden">
                <img
                  src={TRADER_MIX_DATA.brand.founderPhotoMain}
                  alt="Shaheen - Founder & Head Trader"
                  className="w-full h-full object-cover object-top filter brightness-[0.95] contrast-[1.05] group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0b0a09] via-transparent to-transparent opacity-80" />
                
                {/* Floating Verified Badge */}
                <div className="absolute bottom-4 left-4 right-4 p-3.5 rounded-lg bg-[#14120f]/90 backdrop-blur-md border border-[#d6b17a]/30">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-bold text-[#f7f2ea] flex items-center gap-1.5 font-jakarta">
                        <span>Shaheen</span>
                        <CheckCircle className="w-4 h-4 text-[#d6b17a] fill-[#d6b17a]/20" />
                      </div>
                      <div className="text-[11px] text-[#f0d29b] font-medium tracking-wide">
                        Founder & Head Trader, Trader Mix
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-mono-nums font-bold text-[#d6b17a]">
                        SMC & PA
                      </div>
                      <div className="text-[10px] text-[#8e8376]">
                        Specialist
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Philosophy, Credentials & Metrics */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-3">
              <span className="text-xs uppercase tracking-[0.25em] text-[#d6b17a] font-bold">
                The Trader Mix Standard
              </span>
              <h3 className="font-cinzel text-2xl sm:text-3xl font-bold text-[#eee7dc] leading-tight">
                "Trading Is Not A Casino. It Is The Ultimate Game of Probability & Self-Mastery."
              </h3>
              <p className="font-jakarta text-sm sm:text-base text-[#b8ada0] leading-relaxed pt-2">
                When I began my journey in financial markets, the internet was saturated with fake screenshots and useless laggy indicators. I spent years decoding institutional order flow, smart money liquidity grabs, and finding high-probability setups with strict 1:3+ Risk-to-Reward.
              </p>
              <p className="font-jakarta text-sm sm:text-base text-[#b8ada0] leading-relaxed">
                I created <strong className="text-[#f0d29b]">Trader Mix</strong> with one mission: to build a transparent, disciplined family of traders who respect risk, master their emotions, and achieve financial independence without gambling.
              </p>
            </div>

            {/* Core Pillars Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-[#14120e] border border-[#d6b17a]/20 space-y-1.5">
                <div className="flex items-center gap-2 text-sm font-bold text-[#f5e4c3]">
                  <ShieldCheck className="w-4 h-4 text-[#d6b17a]" />
                  <span>Capital Protection First</span>
                </div>
                <p className="text-xs text-[#9d9284] leading-relaxed">
                  Never risk more than 1% of your account per setup. Consistency comes from protecting your downside.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#14120e] border border-[#d6b17a]/20 space-y-1.5">
                <div className="flex items-center gap-2 text-sm font-bold text-[#f5e4c3]">
                  <TrendingUp className="w-4 h-4 text-[#d6b17a]" />
                  <span>Institutional Liquidity (SMC)</span>
                </div>
                <p className="text-xs text-[#9d9284] leading-relaxed">
                  Trade in the direction of bank orders, fair value gaps (FVG), and liquidity sweeps rather than retail patterns.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#14120e] border border-[#d6b17a]/20 space-y-1.5">
                <div className="flex items-center gap-2 text-sm font-bold text-[#f5e4c3]">
                  <Award className="w-4 h-4 text-[#d6b17a]" />
                  <span>Direct Mentorship</span>
                </div>
                <p className="text-xs text-[#9d9284] leading-relaxed">
                  In our $150 course, students get direct Q&A access, live chart reviews, and personal trade feedback.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#14120e] border border-[#d6b17a]/20 space-y-1.5">
                <div className="flex items-center gap-2 text-sm font-bold text-[#f5e4c3]">
                  <Flame className="w-4 h-4 text-[#d6b17a]" />
                  <span>Unfiltered Accountability</span>
                </div>
                <p className="text-xs text-[#9d9284] leading-relaxed">
                  Every trade idea, win or loss, is journaled and reviewed to build resilient psychological execution.
                </p>
              </div>
            </div>

            {/* Quick action button */}
            <div className="pt-2 flex flex-wrap gap-4">
              <button
                onClick={onOpenEnrollModal}
                className="px-6 py-3 rounded-lg bg-gradient-to-r from-[#f0d29b] to-[#c79b61] text-[#14100b] font-bold text-xs sm:text-sm shadow-lg hover:brightness-110 active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>Join Shaheen's Mentorship ($150)</span>
              </button>

              <a
                href={TRADER_MIX_DATA.platforms[0].url}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-3 rounded-lg bg-[#1a1713] border border-[#d6b17a]/30 text-[#f0d29b] font-semibold text-xs sm:text-sm hover:border-[#f0d29b] transition-all flex items-center gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Message on Telegram</span>
              </a>
            </div>

          </div>
        </div>

        {/* Lifestyle & Discipline Editorial Grid with User's Other Photos */}
        <div className="mt-20 pt-16 border-t border-[#d6b17a]/15">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
            <div>
              <span className="text-xs uppercase tracking-[0.25em] text-[#d6b17a] font-bold">
                Behind The Charts
              </span>
              <h4 className="font-cinzel text-2xl sm:text-3xl font-bold text-[#eee7dc] mt-1">
                Discipline as a Way of Life
              </h4>
            </div>
            <p className="text-xs sm:text-sm text-[#9f9486] max-w-md">
              A profitable trader is forged in routine, physical fitness, mental composure, and unrelenting patience.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
            
            {/* Lifestyle Image 1 - Streetwear Kitchen Lounge */}
            <div className="glass-panel rounded-2xl overflow-hidden p-3.5 border border-[#d6b17a]/25 group flex flex-col justify-between">
              <div>
                <div className="relative aspect-[4/3] rounded-xl overflow-hidden mb-4 bg-[#14120f]">
                  <img
                    src={TRADER_MIX_DATA.brand.founderPhotoLifestyle}
                    alt="Shaheen Trading Discipline Lifestyle"
                    className="w-full h-full object-cover object-center filter brightness-95 group-hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0c0a08]/90 via-transparent to-transparent" />
                  <div className="absolute bottom-3 left-3 right-3 text-xs text-[#f5e4c3] font-medium font-jakarta">
                    "Patience before the session opens is as important as the trade itself."
                  </div>
                </div>
                <div className="px-2 pb-1">
                  <h5 className="font-bold text-sm sm:text-base text-[#f7f2eb] mb-1 font-jakarta">
                    Pre-Market Preparation & Lifestyle
                  </h5>
                  <p className="text-xs text-[#9d9284] leading-relaxed">
                    Every day starts with physical wellness, reviewing macro economic news releases, and waiting for the market to deliver our precise A+ setup without chasing candles.
                  </p>
                </div>
              </div>
            </div>

            {/* Lifestyle Image 2 - Phone in Hand, Adjusted Higher and Well Centered */}
            <div className="glass-panel rounded-2xl overflow-hidden p-3.5 border border-[#d6b17a]/25 group flex flex-col justify-between">
              <div>
                {/* Adjusted height and object position so face, upper body and phone are clearly visible higher up */}
                <div className="relative aspect-[4/3] rounded-xl overflow-hidden mb-4 bg-[#14120f]">
                  <img
                    src={TRADER_MIX_DATA.brand.founderPhotoStudio}
                    alt="Shaheen Mentorship & Focus with Phone"
                    className="w-full h-full object-cover object-[center_12%] filter brightness-95 group-hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0c0a08]/90 via-transparent to-transparent" />
                  <div className="absolute bottom-3 left-3 right-3 text-xs text-[#f5e4c3] font-medium font-jakarta">
                    "Personal accountability is the difference between a gambler and a master."
                  </div>
                </div>
                <div className="px-2 pb-1">
                  <h5 className="font-bold text-sm sm:text-base text-[#f7f2eb] mb-1 font-jakarta">
                    1-on-1 Student Guidance & Commitment
                  </h5>
                  <p className="text-xs text-[#9d9284] leading-relaxed">
                    Inside the $150 mentorship, Shaheen inspects student trade journals, corrects bad psychological habits, and supports members through prop firm challenge evaluations.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
