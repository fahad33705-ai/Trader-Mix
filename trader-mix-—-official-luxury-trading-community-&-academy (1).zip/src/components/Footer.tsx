import React from 'react';
import { ArrowUp, ShieldAlert, Heart, ExternalLink } from 'lucide-react';
import { TRADER_MIX_DATA } from '../data/traderData';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative bg-[#080706] border-t border-[#d6b17a]/20 pt-16 pb-12 overflow-hidden text-[#a4998c]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Row */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-12 border-b border-[#d6b17a]/15">
          
          {/* Brand & Motto */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-md bg-[#241e17] border border-[#d6b17a]/30 p-1 flex items-end justify-center gap-0.5">
                <span className="w-1 h-3 bg-[#b88d4e]"></span>
                <span className="w-1 h-6 bg-[#f0d29b]"></span>
                <span className="w-1 h-4 bg-[#d6b17a]"></span>
              </div>
              <span className="font-cinzel text-xl font-bold tracking-[0.16em] text-gold-gradient">
                TRADER MIX
              </span>
            </div>

            <p className="text-xs sm:text-sm text-[#8e8273] max-w-sm leading-relaxed font-jakarta">
              An elite community founded by <strong className="text-[#f7f2ea]">Shaheen</strong>, providing high-probability market insights, the $150 masterclass, and institutional price action education.
            </p>

            <div className="text-xs font-bold tracking-[0.2em] text-[#d6b17a] font-cinzel">
              {TRADER_MIX_DATA.brand.tagline}
            </div>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3 space-y-3">
            <h5 className="text-xs uppercase font-bold text-[#f7f2ea] tracking-wider">
              Navigation
            </h5>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#home" className="hover:text-[#f0d29b] transition-colors">
                  Home & Live Watchlist
                </a>
              </li>
              <li>
                <a href="#founder" className="hover:text-[#f0d29b] transition-colors">
                  Founder Shaheen's Story
                </a>
              </li>
              <li>
                <a href="#course" className="hover:text-[#f0d29b] transition-colors flex items-center gap-1.5">
                  <span>Complete Course ($150)</span>
                  <span className="text-[10px] font-mono-nums bg-[#d6b17a]/20 text-[#f0d29b] px-1.5 rounded">
                    Save $349
                  </span>
                </a>
              </li>
              <li>
                <a href="#calculator" className="hover:text-[#f0d29b] transition-colors">
                  Risk & Position Calculator
                </a>
              </li>
              <li>
                <a href="#community" className="hover:text-[#f0d29b] transition-colors">
                  Frequently Asked Questions
                </a>
              </li>
            </ul>
          </div>

          {/* 4 Social Platforms */}
          <div className="md:col-span-4 space-y-3">
            <h5 className="text-xs uppercase font-bold text-[#f7f2ea] tracking-wider">
              Official Channels
            </h5>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {TRADER_MIX_DATA.platforms.map((p) => (
                <a
                  key={p.id}
                  href={p.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-lg bg-[#12100d] border border-[#d6b17a]/15 hover:border-[#f0d29b] text-[#d4c8b8] hover:text-[#f0d29b] transition-all flex items-center justify-between group"
                >
                  <span className="font-medium truncate">{p.name}</span>
                  <ExternalLink className="w-3 h-3 opacity-60 group-hover:opacity-100 shrink-0" />
                </a>
              ))}
            </div>

            <div className="pt-2 text-[11px] text-[#7d7162]">
              Inquiries: <a href={`mailto:${TRADER_MIX_DATA.brand.email}`} className="text-[#f0d29b] hover:underline font-mono-nums">{TRADER_MIX_DATA.brand.email}</a>
            </div>
          </div>

        </div>

        {/* Regulatory Risk Disclaimer */}
        <div className="py-6 border-b border-[#d6b17a]/15 text-[11px] leading-relaxed text-[#786c5f]">
          <div className="flex items-start gap-2 mb-1 text-amber-500/90 font-bold uppercase tracking-wide">
            <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
            <span>Official Financial Risk Disclaimer</span>
          </div>
          <p>
            Trading foreign exchange (Forex), cryptocurrencies, commodities, and derivatives on margin carries a high level of risk and may not be suitable for all individuals. Before deciding to trade, you should carefully consider your investment objectives, level of experience, and risk appetite. The high degree of leverage can work against you as well as for you. Trader Mix and Shaheen provide educational content and market structure commentary. Nothing on this website constitutes financial or investment advice. Always use strict stop-loss rules and proper risk management.
          </p>
        </div>

        {/* Copyright Bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#786c5f]">
          <div>
            © {new Date().getFullYear()} <span className="text-[#d4c8b8] font-bold">TRADER MIX</span>. All rights reserved.
          </div>

          <div className="flex items-center gap-4">
            <span className="text-[11px] text-[#695e52]">
              Dhaka Regency Executive Style
            </span>
            <button
              onClick={scrollToTop}
              className="p-2 rounded-lg bg-[#14120e] border border-[#d6b17a]/20 text-[#d6b17a] hover:text-white hover:border-[#f0d29b] transition-all cursor-pointer flex items-center gap-1.5"
              aria-label="Scroll back to top"
            >
              <span className="text-[11px] font-semibold">Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
