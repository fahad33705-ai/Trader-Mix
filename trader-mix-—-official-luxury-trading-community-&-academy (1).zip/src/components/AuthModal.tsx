import React, { useState } from 'react';
import { X, Lock, Mail, User, ArrowRight, ShieldCheck, Check } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

interface AuthModalProps {
  isOpen: boolean;
  initialMode?: 'login' | 'signup';
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ 
  isOpen, 
  initialMode = 'login', 
  onClose 
}) => {
  const [mode, setMode] = useState<'login' | 'signup'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-md rounded-2xl glass-panel border-2 border-[#ffc107]/40 bg-[#12100d] p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.85)]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-[#1f1913] text-[#b4a796] hover:text-white transition-all cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Brand Header */}
        <div className="flex flex-col items-center mb-6">
          <BrandLogo size="md" showSubtitle={false} />
          <div className="text-xs text-[#a39789] mt-2">
            Trader Mix Portal & Student Dashboard
          </div>
        </div>

        {/* Tab switcher */}
        <div className="grid grid-cols-2 p-1 rounded-xl bg-[#181410] border border-[#ffc107]/20 mb-6">
          <button
            type="button"
            onClick={() => { setMode('login'); setIsSuccess(false); }}
            className={`py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              mode === 'login' ? 'bg-[#ffc107] text-[#14100b] shadow-sm' : 'text-[#a39789] hover:text-white'
            }`}
          >
            Log In
          </button>
          <button
            type="button"
            onClick={() => { setMode('signup'); setIsSuccess(false); }}
            className={`py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              mode === 'signup' ? 'bg-[#ffc107] text-[#14100b] shadow-sm' : 'text-[#a39789] hover:text-white'
            }`}
          >
            Sign Up
          </button>
        </div>

        {isSuccess ? (
          <div className="py-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 mx-auto flex items-center justify-center">
              <Check className="w-6 h-6 stroke-[3]" />
            </div>
            <h4 className="text-base font-bold text-white">
              {mode === 'login' ? 'Welcome Back!' : 'Account Created Successfully!'}
            </h4>
            <p className="text-xs text-[#a99e90]">
              Redirecting to your Trader Mix student dashboard...
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <div>
                <label className="block text-xs font-semibold text-[#d4c8b8] mb-1">
                  Full Name
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#8e8274] absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter your name"
                    className="w-full pl-9 pr-3 py-2.5 rounded-lg bg-[#181410] border border-[#ffc107]/20 text-xs text-white placeholder-[#685f54] focus:outline-none focus:border-[#ffc107]"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-[#d4c8b8] mb-1">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-[#8e8274] absolute left-3 top-3" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-9 pr-3 py-2.5 rounded-lg bg-[#181410] border border-[#ffc107]/20 text-xs text-white placeholder-[#685f54] focus:outline-none focus:border-[#ffc107]"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center text-xs mb-1">
                <label className="font-semibold text-[#d4c8b8]">Password</label>
                {mode === 'login' && (
                  <a href="#" className="text-[11px] text-[#ffc107] hover:underline">
                    Forgot password?
                  </a>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-[#8e8274] absolute left-3 top-3" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-3 py-2.5 rounded-lg bg-[#181410] border border-[#ffc107]/20 text-xs text-white placeholder-[#685f54] focus:outline-none focus:border-[#ffc107]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-lg btn-sample-yellow text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer mt-2"
            >
              <span>{mode === 'login' ? 'Access Dashboard' : 'Create Free Account'}</span>
              <ArrowRight className="w-3.5 h-3.5 stroke-[3]" />
            </button>

            <div className="text-center pt-2">
              <span className="text-[11px] text-[#7d7163]">
                {mode === 'login' ? "Don't have an account? " : "Already registered? "}
                <button
                  type="button"
                  onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}
                  className="text-[#ffc107] font-bold hover:underline cursor-pointer"
                >
                  {mode === 'login' ? 'Sign Up' : 'Log In'}
                </button>
              </span>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
