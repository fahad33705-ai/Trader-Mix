import React from 'react';
import { X, ArrowUpRight, ShieldCheck, Sparkles, MessageCircle, Mail, CheckCircle2 } from 'lucide-react';
import { TRADER_MIX_DATA } from '../data/traderData';

interface EnrollmentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EnrollmentModal: React.FC<EnrollmentModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      
      {/* Modal Container */}
      <div 
        className="relative w-full max-w-xl rounded-2xl glass-panel border-2 border-[#f0d29b]/40 bg-[#12100d] p-6 sm:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.85)] max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-[#1f1913] text-[#b4a796] hover:text-white hover:bg-[#2c2217] transition-all cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#271f15] border border-[#f0d29b]/40 text-xs font-bold text-[#f0d29b] uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Official Mentorship Enrollment</span>
          </div>

          <h3 className="font-cinzel text-2xl sm:text-3xl font-bold text-[#f7f2ea]">
            Trader Mix <span className="text-gold-gradient">$150 Masterclass</span>
          </h3>

          <p className="text-xs sm:text-sm text-[#b8ada0] mt-1 font-jakarta">
            Direct mentorship with <strong className="text-white">Shaheen</strong> + Lifetime VIP Telegram Signal Access.
          </p>
        </div>

        {/* Value Tag Box */}
        <div className="p-4 rounded-xl bg-[#1b1712] border border-[#d6b17a]/25 flex items-center justify-between mb-6 text-xs text-[#d8cec2]">
          <div className="flex items-center gap-2">
            <span className="font-bold text-gold-subtle text-lg font-mono-nums">$150 USD</span>
            <span className="text-[#8e8273]">• One-time Lifetime Access</span>
          </div>
          <span className="text-emerald-400 font-semibold text-xs bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1 rounded-full">
            Instant Verification
          </span>
        </div>

        {/* Enrollment Highlights */}
        <div className="space-y-2.5 mb-6 p-4 rounded-xl bg-[#16130f] border border-[#d6b17a]/15 text-xs text-[#cfc4b6]">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#f0d29b] shrink-0" />
            <span>8-Week Complete Institutional Price Action & Smart Money Concepts</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#f0d29b] shrink-0" />
            <span>Daily VIP Pre-Market Analysis & High-Probability Setups</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#f0d29b] shrink-0" />
            <span>Weekly Live Backtesting & Direct Q&A with Shaheen</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#f0d29b] shrink-0" />
            <span>Personal 1-on-1 Guidance & Trade Journal Audit</span>
          </div>
        </div>

        {/* Direct Telegram Enrollment Action */}
        <div className="space-y-3 mb-4">
          <div className="text-xs uppercase font-bold text-[#d6b17a] tracking-wider text-center">
            Connect Directly with Shaheen
          </div>

          <a
            href="https://t.me/TraderMix00"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-4 px-4 rounded-xl bg-[#38bdf8] text-[#0b141d] font-black text-sm sm:text-base hover:brightness-110 active:scale-[0.99] transition-all shadow-[0_8px_25px_rgba(56,189,248,0.4)] flex items-center justify-center gap-2.5"
          >
            <MessageCircle className="w-5 h-5 fill-current" />
            <span>Contact Shaheen on Telegram (@TraderMix00)</span>
            <ArrowUpRight className="w-4 h-4 stroke-[3]" />
          </a>

          <p className="text-[11px] text-[#9ca3af] text-center leading-relaxed">
            Message Shaheen directly on Telegram to enroll in the $150 Masterclass and receive your VIP Channel invitation link immediately.
          </p>
        </div>

        {/* Direct Email Link Alternative */}
        <div className="pt-4 border-t border-[#d6b17a]/15 flex items-center justify-between text-xs text-[#a99e90]">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-[#d6b17a]" />
            <span>Verified Official Mentor</span>
          </span>
          <a
            href={`mailto:${TRADER_MIX_DATA.brand.email}?subject=Trader%20Mix%20Course%20Enrollment%20($150)&body=Hello%20Shaheen,%20I%20want%20to%20enroll%20in%20the%20Trader%20Mix%20$150%20Masterclass.`}
            className="text-[#f0d29b] hover:underline flex items-center gap-1 font-semibold"
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Email Shaheen</span>
          </a>
        </div>

      </div>
    </div>
  );
};
