import React from 'react';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'hero';
  showSubtitle?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ size = 'sm', showSubtitle = true }) => {
  if (size === 'hero') {
    return (
      <div className="flex flex-col items-center justify-center text-center select-none relative">
        {/* Crown on top */}
        <div className="mb-2 relative">
          <svg className="w-12 h-10 sm:w-16 sm:h-12 fill-current text-[#FFC72C] drop-shadow-[0_0_15px_rgba(255,199,44,0.8)]" viewBox="0 0 24 24">
            <path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z"/>
          </svg>
        </div>

        {/* Main Brand Title: TRADER (Metallic Silver) + MIX (Brush Gold) */}
        <div className="flex items-center justify-center font-extrabold tracking-[-0.03em] leading-none mb-3">
          <span className="text-4xl sm:text-7xl lg:text-8xl tracking-tight text-metallic-silver font-sans italic pr-2 drop-shadow-[0_4px_16px_rgba(0,0,0,0.9)]">
            TRADER
          </span>
          <span className="text-4xl sm:text-7xl lg:text-8xl tracking-tight text-brush-gold font-sans italic drop-shadow-[0_0_25px_rgba(255,179,0,0.8)]">
            MIX
          </span>
        </div>

        {/* Subtitle with gold stars */}
        {showSubtitle && (
          <div className="flex items-center justify-center gap-3 text-xs sm:text-base font-bold tracking-[0.25em] text-[#F8FAFC] uppercase drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
            <span>TRADE</span>
            <span className="text-[#FFC72C] text-sm">✦</span>
            <span>LEARN</span>
            <span className="text-[#FFC72C] text-sm">✦</span>
            <span>GROW</span>
          </div>
        )}
      </div>
    );
  }

  // Sm / Md / Lg version for Navbar and Footer
  const textSizes = {
    sm: 'text-xl sm:text-2xl',
    md: 'text-2xl sm:text-3xl',
    lg: 'text-3xl sm:text-4xl',
  };

  const crownSizes = {
    sm: 'w-5 h-4 -top-3.5 left-0',
    md: 'w-6 h-5 -top-4 left-0',
    lg: 'w-8 h-6 -top-5 left-0',
  };

  return (
    <div className="flex flex-col select-none relative group">
      <div className="relative inline-block">
        {/* Crown */}
        <div className={`absolute ${crownSizes[size]}`}>
          <svg className="w-full h-full fill-current text-[#FFC72C] drop-shadow-[0_0_8px_rgba(255,199,44,0.7)]" viewBox="0 0 24 24">
            <path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z"/>
          </svg>
        </div>

        {/* Text */}
        <div className={`flex items-center font-extrabold italic leading-none ${textSizes[size]}`}>
          <span className="text-metallic-silver tracking-tight pr-1">TRADER</span>
          <span className="text-brush-gold tracking-tight">MIX</span>
        </div>
      </div>

      {showSubtitle && (
        <div className="text-[8px] sm:text-[9px] font-bold tracking-[0.22em] text-[#E2E8F0] uppercase -mt-0.5 flex items-center gap-1.5">
          <span>TRADE</span>
          <span className="text-[#FFC72C] text-[8px]">✦</span>
          <span>LEARN</span>
          <span className="text-[#FFC72C] text-[8px]">✦</span>
          <span>GROW</span>
        </div>
      )}
    </div>
  );
};
