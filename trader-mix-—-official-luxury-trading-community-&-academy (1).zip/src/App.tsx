/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { SampleHeroAndCards } from './components/SampleHeroAndCards';
import { FounderSection } from './components/FounderSection';
import { CourseSection } from './components/CourseSection';
import { TradingCalculator } from './components/TradingCalculator';
import { CommunitySection } from './components/CommunitySection';
import { Footer } from './components/Footer';
import { EnrollmentModal } from './components/EnrollmentModal';
import { AuthModal } from './components/AuthModal';
import { CommunityModal } from './components/CommunityModal';
import { MessageCircle, ArrowUpRight } from 'lucide-react';
import { TRADER_MIX_DATA } from './data/traderData';

export default function App() {
  const [isEnrollModalOpen, setIsEnrollModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [isCommunityModalOpen, setIsCommunityModalOpen] = useState(false);

  const handleOpenAuth = (mode: 'login' | 'signup') => {
    setAuthMode(mode);
    setIsAuthModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#070707] text-[#eee7dc] flex flex-col selection:bg-[#ffc107]/30 selection:text-[#f7e3b8] relative font-jakarta">
      
      {/* Top Navbar matching sample mockup */}
      <Navbar 
        onOpenEnrollModal={() => setIsEnrollModalOpen(true)}
        onOpenAuthModal={handleOpenAuth}
        onOpenCommunityModal={() => setIsCommunityModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-grow">
        
        {/* Exact Sample Hero & 4 Cards Grid as requested in image_879d9f85.png */}
        <SampleHeroAndCards 
          onOpenEnrollModal={() => setIsEnrollModalOpen(true)}
          onOpenCommunityModal={() => setIsCommunityModalOpen(true)}
        />

        {/* Founder & Head Trader Spotlight (Shaheen's Luxury Portraits & Philosophy) */}
        <FounderSection onOpenEnrollModal={() => setIsEnrollModalOpen(true)} />

        {/* Detailed $150 Masterclass & Mentorship Section */}
        <CourseSection onOpenEnrollModal={() => setIsEnrollModalOpen(true)} />

        {/* Interactive Position Size & 1:3 Risk-to-Reward Calculator */}
        <TradingCalculator onOpenEnrollModal={() => setIsEnrollModalOpen(true)} />

        {/* FAQ Accordion */}
        <CommunitySection onOpenEnrollModal={() => setIsEnrollModalOpen(true)} />

      </main>

      {/* Footer */}
      <Footer />

      {/* Modals */}
      <EnrollmentModal
        isOpen={isEnrollModalOpen}
        onClose={() => setIsEnrollModalOpen(false)}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        initialMode={authMode}
        onClose={() => setIsAuthModalOpen(false)}
      />

      <CommunityModal
        isOpen={isCommunityModalOpen}
        onClose={() => setIsCommunityModalOpen(false)}
      />

      {/* Floating Quick Telegram Contact Button */}
      <div className="fixed bottom-6 right-6 z-40 hidden sm:flex items-center gap-2">
        <a
          href={TRADER_MIX_DATA.platforms[0].url}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-[#0088cc] hover:bg-[#0099e6] text-white font-bold text-xs shadow-[0_6px_20px_rgba(0,136,204,0.5)] hover:scale-105 transition-all"
        >
          <MessageCircle className="w-4 h-4 fill-current" />
          <span>Telegram @TraderMix00</span>
          <ArrowUpRight className="w-3.5 h-3.5" />
        </a>
      </div>

    </div>
  );
}
