export interface PlatformLink {
  id: string;
  name: string;
  handle: string;
  description: string;
  url: string;
  icon: 'telegram' | 'facebook' | 'tiktok' | 'youtube';
  color: string;
  badge: string;
  members: string;
}

export interface CourseModule {
  number: string;
  title: string;
  duration: string;
  highlights: string[];
}

export interface Testimonial {
  name: string;
  role: string;
  city: string;
  comment: string;
  result: string;
  rating: number;
}

export interface MarketAsset {
  symbol: string;
  name: string;
  price: string;
  change: string;
  isPositive: boolean;
  high: string;
  low: string;
}

export const TRADER_MIX_DATA = {
  brand: {
    name: "TRADER MIX",
    tagline: "LEARN • GROW • SUCCEED",
    founder: "Shaheen",
    founderRole: "Founder & Head Trader",
    location: "Dhaka, Bangladesh",
    email: "fahadmix33705@gmail.com",
    established: "2021",
    heroImage: "/assets/aistudio/Gemini_Generated_Image_4gmyfh4gmyfh4gmy_e3c72258.jpg",
    founderPhotoMain: "/assets/aistudio/IMG_5608.JPG_2b4b2f21.jpeg",
    founderPhotoLifestyle: "/assets/aistudio/IMG_9582.JPG_518627bc.jpeg",
    founderPhotoStudio: "/assets/aistudio/IMG_9147_c6884b1e.JPG",
    liveTradeLogo: "/assets/aistudio/240cb356-2b6b-47c1-9a4c-f27544b31915_d27fd848.png",
  },

  course: {
    name: "Trader Mix Elite Masterclass & VIP Mentorship",
    price: 150,
    originalPrice: 499,
    currency: "USD",
    tagline: "From Foundation to Institutional Liquidity Mastery",
    accessType: "Lifetime Access + VIP Signals",
    duration: "8 Weeks Structured + Lifetime VIP Telegram Updates",
    features: [
      "Complete Institutional Price Action & Market Structure",
      "Smart Money Concepts (SMC) & Liquidity Grab Identification",
      "High-Probability Order Block & Fair Value Gap (FVG) Strategy",
      "Strict Risk-to-Reward Ratio System (Minimum 1:3 RR)",
      "Daily Pre-Market Chart Breakdowns on Telegram VIP",
      "Weekly Live Zoom/Telegram Q&A & Backtesting with Shaheen",
      "Prop Firm Challenge Passing Blueprint (FTMO, FundedNext, etc.)",
      "Private VIP Traders Lounge & Personal 1-on-1 Guidance"
    ],
    curriculum: [
      {
        number: "01",
        title: "Market Anatomy & Advanced Candlestick Behaviour",
        duration: "Week 1",
        highlights: [
          "Understanding True Volume & Institutional Footprints",
          "Candlestick wick rejections vs true break of structure (BOS)",
          "Multi-timeframe synchronization (Monthly down to 1-Min)"
        ]
      },
      {
        number: "02",
        title: "Smart Money Concepts & Liquidity Engineering",
        duration: "Week 2",
        highlights: [
          "Buy-side vs Sell-side Liquidity pools detection",
          "Institutional Inducement vs genuine trend continuation",
          "Fair Value Gaps (FVG) and mitigation fill strategies"
        ]
      },
      {
        number: "03",
        title: "Supply, Demand & Precise Entry Models",
        duration: "Week 3",
        highlights: [
          "Refined Order Block selection (Refining to 5m/1m for sniper entries)",
          "Breaker blocks, change of character (CHoCH) confirmation",
          "Session timings: London & New York Killzones"
        ]
      },
      {
        number: "04",
        title: "Risk Management, Psychology & Prop Firm Mastery",
        duration: "Week 4",
        highlights: [
          "Never risking more than 0.5%–1% per trade",
          "Emotional detachment: Overcoming FOMO and revenge trading",
          "Scale-in techniques & compounding capital to financial freedom"
        ]
      }
    ]
  },

  platforms: [
    {
      id: "telegram",
      name: "Telegram Community",
      handle: "@TraderMix00",
      description: "Daily chart analysis, instant market updates, educational breakdowns, and voice session alerts.",
      url: "https://t.me/TraderMix00",
      icon: "telegram",
      color: "#38bdf8",
      badge: "Official Channel",
      members: "Join Free Community"
    },
    {
      id: "facebook",
      name: "Facebook Page",
      handle: "Trader Mix Official",
      description: "Follow for trading motivation, verified student setups, announcements, and market perspectives.",
      url: "https://www.facebook.com/share/1QEBVduZXq/?mibextid=wwXIfr",
      icon: "facebook",
      color: "#60a5fa",
      badge: "Official Page",
      members: "Follow Us"
    },
    {
      id: "tiktok",
      name: "TikTok Channel",
      handle: "@tradermix01",
      description: "Quick 60-second price action breakdowns, live trade reels, psychological rules, and lifestyle insights.",
      url: "https://www.tiktok.com/@tradermix01?_r=1&_t=ZS-9AQ060LT6jk",
      icon: "tiktok",
      color: "#f43f5e",
      badge: "Video Shorts",
      members: "Watch Videos"
    },
    {
      id: "youtube",
      name: "YouTube Channel",
      handle: "@Tradermixofficial",
      description: "Full in-depth video tutorials, live session replays, strategy walkthroughs, and prop firm reviews.",
      url: "https://www.youtube.com/@Tradermixofficial",
      icon: "youtube",
      color: "#ef4444",
      badge: "Official Channel",
      members: "Subscribe"
    }
  ] as PlatformLink[],

  marketAssets: [
    {
      symbol: "XAU/USD",
      name: "Gold / US Dollar",
      price: "2,748.60",
      change: "+1.42%",
      isPositive: true,
      high: "2,754.20",
      low: "2,718.50"
    },
    {
      symbol: "EUR/USD",
      name: "Euro / US Dollar",
      price: "1.0874",
      change: "+0.31%",
      isPositive: true,
      high: "1.0898",
      low: "1.0832"
    },
    {
      symbol: "GBP/USD",
      name: "British Pound",
      price: "1.2982",
      change: "-0.24%",
      isPositive: false,
      high: "1.3025",
      low: "1.2950"
    },
    {
      symbol: "BTC/USD",
      name: "Bitcoin Spot",
      price: "69,450.00",
      change: "+2.85%",
      isPositive: true,
      high: "70,120.00",
      low: "67,800.00"
    },
    {
      symbol: "US30",
      name: "Dow Jones Index",
      price: "42,210.00",
      change: "+0.55%",
      isPositive: true,
      high: "42,380.00",
      low: "41,940.00"
    }
  ] as MarketAsset[],

  testimonials: [
    {
      name: "Tanvir Ahmed",
      role: "Funded Trader ($100k Account)",
      city: "Chittagong",
      comment: "Before joining Trader Mix, I blew 3 prop firm accounts trying random indicators. Shaheen bhai's 1:3 RR rule and SMC liquidity entry completely changed my trading career. Passed my $100K challenge within 22 days.",
      result: "Funded with $100,000",
      rating: 5
    },
    {
      name: "Rashedul Karim",
      role: "Forex & Gold Trader",
      city: "Dhaka",
      comment: "The $150 mentorship is worth ten times more. The live Telegram charts and weekly backtest sessions give you institutional perspective. No gambling, pure discipline.",
      result: "+$4,800 Profit First Month",
      rating: 5
    },
    {
      name: "Nazmul Huda",
      role: "Crypto & Forex Swing Trader",
      city: "Sylhet",
      comment: "Best trading community in Bangladesh by far. Shaheen is always transparent, never sells false hype, and teaches real psychology. Highly recommended!",
      result: "Consistent 8.5% Monthly ROI",
      rating: 5
    }
  ] as Testimonial[],

  faqs: [
    {
      question: "What is included in the $150 Trader Mix Course?",
      answer: "The $150 course provides full lifetime access to the 8-week structured masterclass (covering basic to advanced Smart Money Concepts, Price Action, Liquidity Grabs, and Risk Management), access to our private VIP Telegram signal channel, weekly live chart breakdown sessions, and direct mentorship Q&A with Shaheen."
    },
    {
      question: "I am a complete beginner. Is this suitable for me?",
      answer: "Yes, the course starts from ground zero (market structure, broker selection, Risk/Reward calculation, lot sizing) and progresses step-by-step into institutional entry models. Beginners will build healthy trading habits without losing capital on bad information."
    },
    {
      question: "How do I enroll and make the $150 payment?",
      answer: "You can click any 'Enroll in $150 Course' button on this page to contact Shaheen directly via Telegram (@TraderMix00) or email (fahadmix33705@gmail.com). We accept Crypto (USDT TRC20/BEP20), Binance Pay, and local bank transfers with instant verification."
    },
    {
      question: "Are the Telegram, YouTube, Facebook, and TikTok channels free to join?",
      answer: "Yes! Our public Telegram channel, YouTube tutorials, Facebook page, and TikTok videos are 100% free for everyone. The $150 fee is exclusively for the comprehensive Academy Masterclass & private VIP mentorship circle."
    }
  ]
};
